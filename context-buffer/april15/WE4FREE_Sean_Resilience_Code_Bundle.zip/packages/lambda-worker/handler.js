import { classifyError } from '../common/classifyError.js';
import { decide } from '../common/decide.js';
import policy from '../policy/resilience-policy.json' assert { type: 'json' };

export const handler = async (event) => {
  const failures = [];

  for (const record of event.Records) {
    try {
      // TODO: Implement idempotent processing logic
      console.log('Processing message:', record.messageId);
    } catch (err) {
      const cls = classifyError(err);
      const decision = decide(cls, policy, {
        idempotent: true,
        breaker_open: false,
        attempts_used: parseInt(record.attributes?.ApproximateReceiveCount || '1') - 1,
        degrade_allowed: false
      });

      console.error('Error classified:', cls, decision);
      failures.push({ itemIdentifier: record.messageId });
    }
  }

  return { batchItemFailures: failures };
};
