import express from 'express';
import axios from 'axios';
import CircuitBreaker from 'opossum';
import { classifyError } from '../common/classifyError.js';
import { decide } from '../common/decide.js';
import policy from '../policy/resilience-policy.json' assert { type: 'json' };

const app = express();
app.use(express.json());

const http = axios.create({ timeout: 6000 });

async function callExternal(payload) {
  const res = await http.post('https://api.example.com/do', payload);
  return res.data;
}

const breaker = new CircuitBreaker(callExternal, {
  timeout: 7000,
  errorThresholdPercentage: 50,
  resetTimeout: 30000
});

app.post('/run', async (req, res) => {
  try {
    const result = await breaker.fire(req.body);
    res.json({ success: true, result });
  } catch (err) {
    const cls = classifyError(err);
    const decision = decide(cls, policy, {
      idempotent: true,
      breaker_open: breaker.opened,
      attempts_used: 0,
      degrade_allowed: true
    });

    res.status(500).json({ error: true, classification: cls, decision });
  }
});

app.listen(3000, () => console.log('Service running on port 3000'));
