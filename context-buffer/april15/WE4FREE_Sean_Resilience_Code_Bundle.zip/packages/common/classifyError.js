export function classifyError(err) {
  const out = {
    error_domain: 'execution',
    retryable: false,
    scope: 'local_agent',
    risk_level: 'medium',
    containment_required: true,
    error_type: 'UNKNOWN'
  };

  const status = err?.response?.status;

  if (status) {
    if (status === 429 || status >= 500) {
      out.retryable = true;
      out.containment_required = false;
      out.error_type = `HTTP_${status}`;
      return out;
    }
    if (status >= 400) {
      out.error_domain = 'contract';
      out.error_type = `HTTP_${status}`;
      return out;
    }
  }

  if (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT') {
    out.retryable = true;
    out.containment_required = false;
    out.error_type = err.code;
    return out;
  }

  if (err.name === 'ConstitutionViolation') {
    return {
      error_domain: 'constitution',
      retryable: false,
      scope: 'global_run',
      risk_level: 'high',
      containment_required: true,
      error_type: 'CONSTITUTION_VIOLATION'
    };
  }

  return out;
}
