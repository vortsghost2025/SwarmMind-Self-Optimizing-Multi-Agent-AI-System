import fs from "fs";
import path from "path";
import yargs from "yargs";
import { hideBin } from "yargs/helpers";
import crypto from "crypto";

type Trace = any;

function sha256(v: any): string {
  const s = typeof v === "string" ? v : JSON.stringify(v);
  return crypto.createHash("sha256").update(s).digest("hex");
}

function loadJson(p: string) {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}

function verifyCheckpoints(trace: Trace, stateSnapshots: Record<string, any>) {
  const results: {name: string; expected: string; actual: string; ok: boolean}[] = [];
  for (const cp of trace.checkpoints ?? []) {
    const snap = stateSnapshots[cp.name];
    if (snap === undefined) {
      results.push({name: cp.name, expected: cp.state_hash, actual: "MISSING_SNAPSHOT", ok: false});
      continue;
    }
    const actual = sha256(snap);
    results.push({name: cp.name, expected: cp.state_hash, actual, ok: actual === cp.state_hash});
  }
  return results;
}

async function main() {
  const argv = await yargs(hideBin(process.argv))
    .command("validate", "Validate deterministic properties of a trace", (y) =>
      y.option("trace", {type:"string", demandOption:true})
       .option("snapshots", {type:"string", describe:"JSON file of checkpoint snapshots keyed by checkpoint name"})
    )
    .command("replay", "Replay a trace deterministically using recorded tool responses", (y) =>
      y.option("trace", {type:"string", demandOption:true})
       .option("mode", {type:"string", default:"stub", choices:["stub","validate-only"]})
       .option("out", {type:"string", default:"replay-output.json"})
    )
    .demandCommand(1)
    .help()
    .parse();

  const cmd = (argv._[0] as string) || "validate";
  const tracePath = argv.trace as string;
  const trace: Trace = loadJson(tracePath);

  if (cmd === "validate") {
    const snapshotsPath = (argv.snapshots as string) || "";
    const snapshots = snapshotsPath ? loadJson(snapshotsPath) : {};
    const cps = verifyCheckpoints(trace, snapshots);
    const toolCalls = trace.tool_calls?.length ?? 0;
    const violations = (trace.constraint_evals ?? []).flatMap((e: any) => e.violations ?? []);
    const report = {
      trace_id: trace.trace_id,
      run_id: trace.run_id,
      tool_calls: toolCalls,
      violations_count: violations.length,
      checkpoint_verification: cps,
      ok: cps.every(c => c.ok)
    };
    console.log(JSON.stringify(report, null, 2));
    process.exit(report.ok ? 0 : 2);
  }

  if (cmd === "replay") {
    const mode = argv.mode as string;
    // In "stub" mode: we do NOT call real tools; we re-emit recorded tool responses.
    const replay = {
      trace_id: trace.trace_id,
      run_id: trace.run_id,
      mode,
      tool_calls_replayed: [] as any[],
    };

    for (const tc of trace.tool_calls ?? []) {
      const out = {
        tool_call_id: tc.tool_call_id,
        tool: tc.tool,
        // Use recorded response pointer/hash if present
        response: tc.response ?? null,
        status: tc.status ?? "unknown"
      };
      replay.tool_calls_replayed.push(out);
    }

    const outPath = path.resolve(argv.out as string);
    fs.writeFileSync(outPath, JSON.stringify(replay, null, 2));
    console.log(`Wrote replay output: ${outPath}`);
    process.exit(0);
  }
}

main().catch((e) => {
  console.error("Replay CLI fatal:", e);
  process.exit(1);
});
