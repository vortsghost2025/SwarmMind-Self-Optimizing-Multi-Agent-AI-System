import crypto from 'crypto';

export function newTrace() {
  return {
    trace_id: crypto.randomUUID(),
    run_id: crypto.randomUUID(),
    timestamp_start: new Date().toISOString(),
    tool_calls: [],
    constraint_evals: [],
    decision_path: [],
    checkpoints: []
  };
}

export function addDecision(trace, decision) {
  trace.decision_path.push({ ts: new Date().toISOString(), ...decision });
}

export function checkpoint(trace, name, stateObj) {
  const hash = crypto.createHash('sha256')
    .update(JSON.stringify(stateObj))
    .digest('hex');
  trace.checkpoints.push({ name, ts: new Date().toISOString(), state_hash: hash });
  return hash;
}
