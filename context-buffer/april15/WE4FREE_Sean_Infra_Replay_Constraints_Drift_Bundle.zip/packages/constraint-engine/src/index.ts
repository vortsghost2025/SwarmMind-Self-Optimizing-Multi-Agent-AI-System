export type ConstraintStage = "pre_action" | "post_action" | "pre_output";

export type Constraint = {
  id: string;
  type: string;
  severity: "low" | "medium" | "high" | "critical";
  config: Record<string, any>;
};

export type ConstraintEval = {
  stage: ConstraintStage;
  constraint_set: string;
  result: "pass" | "fail";
  violations?: { constraint_id: string; severity: string; evidence: any }[];
  details?: any;
};

export class ConstitutionViolation extends Error {
  public eval: ConstraintEval;
  constructor(message: string, ev: ConstraintEval) {
    super(message);
    this.name = "ConstitutionViolation";
    this.eval = ev;
  }
}

export class ConstraintEngine {
  private constraintSetId: string;
  private rules: Record<ConstraintStage, Constraint[]>;

  constructor(constraintSetId: string, rules: Record<ConstraintStage, Constraint[]>) {
    this.constraintSetId = constraintSetId;
    this.rules = rules;
  }

  evaluate(stage: ConstraintStage, context: any): ConstraintEval {
    const constraints = this.rules[stage] ?? [];
    const violations: { constraint_id: string; severity: string; evidence: any }[] = [];

    for (const c of constraints) {
      const v = this.evalOne(c, context);
      if (v) violations.push(v);
    }

    return {
      stage,
      constraint_set: this.constraintSetId,
      result: violations.length ? "fail" : "pass",
      violations: violations.length ? violations : undefined
    };
  }

  enforce(stage: ConstraintStage, context: any): ConstraintEval {
    const ev = this.evaluate(stage, context);
    if (ev.result === "fail") {
      throw new ConstitutionViolation(`Constitution failed at ${stage}`, ev);
    }
    return ev;
  }

  // Minimal rule library — extend as needed.
  private evalOne(c: Constraint, ctx: any) {
    switch (c.type) {
      case "allowlist_tool": {
        const tool = ctx?.tool;
        const allowed = new Set(c.config?.allowed_tools ?? []);
        if (tool && !allowed.has(tool)) {
          return { constraint_id: c.id, severity: c.severity, evidence: { tool, allowed: [...allowed] } };
        }
        return null;
      }
      case "budget_toolcalls": {
        const used = Number(ctx?.tool_calls_used ?? 0);
        const max = Number(c.config?.max ?? 0);
        if (max && used > max) {
          return { constraint_id: c.id, severity: c.severity, evidence: { used, max } };
        }
        return null;
      }
      case "schema_presence": {
        const resp = ctx?.response ?? {};
        const required: string[] = c.config?.required_fields ?? [];
        const missing = required.filter((k) => resp?.[k] === undefined);
        if (missing.length) {
          return { constraint_id: c.id, severity: c.severity, evidence: { missing } };
        }
        return null;
      }
      case "label_degraded_if_used": {
        // If degraded=true in context, enforce output has a degraded label.
        const degraded = Boolean(ctx?.degraded);
        const output = ctx?.output ?? {};
        if (degraded && !output?.labels?.includes?.("degraded")) {
          return { constraint_id: c.id, severity: c.severity, evidence: { degraded, labels: output?.labels } };
        }
        return null;
      }
      default:
        // Unknown constraint types should fail-safe (treat as violation) in strict mode,
        // but here we report as informational until you decide policy.
        return null;
    }
  }
}
