import fs from "fs";
import path from "path";
import yargs from "yargs";
import { hideBin } from "yargs/helpers";

type Trace = any;

function readJson(p: string): any {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}

function listTraceFiles(dir: string): string[] {
  const out: string[] = [];
  for (const f of fs.readdirSync(dir)) {
    const full = path.join(dir, f);
    if (fs.statSync(full).isDirectory()) continue;
    if (f.endsWith(".json")) out.push(full);
  }
  return out;
}

function summarizeTrace(t: Trace) {
  const violations = (t.constraint_evals ?? []).flatMap((e: any) => e.violations ?? []);
  const decisions = (t.decision_path ?? []).map((d: any) => d.decision ?? d.strategy ?? "UNKNOWN");
  const tools = (t.tool_calls ?? []).map((c: any) => c.tool ?? "unknown");
  const degraded = decisions.includes("DEGRADE");
  return {
    tool_calls: (t.tool_calls ?? []).length,
    violations_count: violations.length,
    decisions,
    tools,
    degraded
  };
}

function dist(counts: Record<string, number>, total: number) {
  const d: Record<string, number> = {};
  for (const [k, v] of Object.entries(counts)) d[k] = total ? v / total : 0;
  return d;
}

// Simple drift score: weighted L1 distance over decision/tool distributions + violation rate delta.
// This is intentionally interpretable (Paper D friendly).
function driftScore(base: any, cur: any) {
  const wDecision = 0.45;
  const wTool = 0.35;
  const wViol = 0.20;

  const keysDec = new Set([...Object.keys(base.decDist), ...Object.keys(cur.decDist)]);
  let l1Dec = 0;
  for (const k of keysDec) l1Dec += Math.abs((base.decDist[k] ?? 0) - (cur.decDist[k] ?? 0));

  const keysTool = new Set([...Object.keys(base.toolDist), ...Object.keys(cur.toolDist)]);
  let l1Tool = 0;
  for (const k of keysTool) l1Tool += Math.abs((base.toolDist[k] ?? 0) - (cur.toolDist[k] ?? 0));

  const violDelta = Math.abs((base.violRate ?? 0) - (cur.violRate ?? 0));

  const score = wDecision*l1Dec + wTool*l1Tool + wViol*violDelta;
  return { score, l1Dec, l1Tool, violDelta };
}

async function main() {
  const argv = await yargs(hideBin(process.argv))
    .command("baseline", "Create a baseline profile from a directory of traces", (y) =>
      y.option("traces", {type:"string", demandOption:true})
       .option("out", {type:"string", default:"baseline.json"})
    )
    .command("compare", "Compare a directory of traces to a baseline profile", (y) =>
      y.option("baseline", {type:"string", demandOption:true})
       .option("traces", {type:"string", demandOption:true})
       .option("out", {type:"string", default:"drift-report.json"})
    )
    .demandCommand(1)
    .help()
    .parse();

  const cmd = argv._[0] as string;

  function buildProfile(dir: string) {
    const files = listTraceFiles(dir);
    const decCounts: Record<string, number> = {};
    const toolCounts: Record<string, number> = {};
    let viol = 0;
    let runs = 0;

    for (const f of files) {
      const t = readJson(f);
      const s = summarizeTrace(t);
      runs += 1;
      viol += s.violations_count > 0 ? 1 : 0;

      for (const d of s.decisions) decCounts[d] = (decCounts[d] ?? 0) + 1;
      for (const tool of s.tools) toolCounts[tool] = (toolCounts[tool] ?? 0) + 1;
    }

    const decTotal = Object.values(decCounts).reduce((a,b)=>a+b,0);
    const toolTotal = Object.values(toolCounts).reduce((a,b)=>a+b,0);

    return {
      generated_at: new Date().toISOString(),
      runs,
      violRate: runs ? viol / runs : 0,
      decDist: dist(decCounts, decTotal),
      toolDist: dist(toolCounts, toolTotal)
    };
  }

  if (cmd === "baseline") {
    const profile = buildProfile(argv.traces as string);
    fs.writeFileSync(argv.out as string, JSON.stringify(profile, null, 2));
    console.log(`Wrote baseline: ${argv.out}`);
    process.exit(0);
  }

  if (cmd === "compare") {
    const base = readJson(argv.baseline as string);
    const cur = buildProfile(argv.traces as string);
    const drift = driftScore(base, cur);

    // Simple flagging thresholds (tune later)
    const flags = {
      drift_high: drift.score >= 0.35,
      drift_medium: drift.score >= 0.20 && drift.score < 0.35,
      viol_spike: drift.violDelta >= 0.10
    };

    const report = { baseline: base, current: cur, drift, flags };
    fs.writeFileSync(argv.out as string, JSON.stringify(report, null, 2));
    console.log(`Wrote drift report: ${argv.out}`);
    process.exit(flags.drift_high || flags.viol_spike ? 2 : 0);
  }
}

main().catch((e) => {
  console.error("Drift CLI fatal:", e);
  process.exit(1);
});
