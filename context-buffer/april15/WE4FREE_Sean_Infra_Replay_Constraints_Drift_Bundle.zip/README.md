# WE4FREE / Sean — Advanced Resilience Bundle

This bundle contains:
1) **Terraform** infra module set (SQS + DLQ + Lambda + S3 quarantine + DynamoDB idempotency + alarms)
2) **CDK (TypeScript)** infra stack with equivalent resources
3) **Deterministic Replay CLI** (`we4free-replay`)
4) **Constraint Engine Skeleton** (`@we4free/constraint-engine`)
5) **Drift Detection Extension** (`we4free-drift`) aligned to Paper D (interpretable drift score)

## Install/build (from repo root)
```bash
# replay CLI
cd packages/replay-cli && npm i && npm run build

# drift detection CLI
cd ../drift-detection && npm i && npm run build

# constraint engine
cd ../constraint-engine && npm i && npm run build
```

## Replay CLI
Validate a trace with checkpoint snapshots:
```bash
we4free-replay validate --trace ./trace.json --snapshots ./snapshots.json
```

Replay (stubbed, no real tool calls):
```bash
we4free-replay replay --trace ./trace.json --mode stub --out replay-output.json
```

## Drift Detection CLI (Paper D)
Create a baseline:
```bash
we4free-drift baseline --traces ./traces_baseline --out baseline.json
```

Compare current traces to baseline:
```bash
we4free-drift compare --baseline baseline.json --traces ./traces_current --out drift-report.json
```

## Notes (important)
- This bundle is intentionally **safe by default**: constitutional/integrity/contract errors do not retry.
- Deterministic replay assumes tool I/O is recorded in the trace (or stubbed via pointers).
- The constraint engine is a skeleton — extend rule types to match your Constraint Lattice formalism.
