import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as sqs from "aws-cdk-lib/aws-sqs";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as iam from "aws-cdk-lib/aws-iam";
import * as s3 from "aws-cdk-lib/aws-s3";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as sources from "aws-cdk-lib/aws-lambda-event-sources";
import * as cw from "aws-cdk-lib/aws-cloudwatch";

export class SeanResilienceStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const quarantine = new s3.Bucket(this, "QuarantineBucket", {
      encryption: s3.BucketEncryption.S3_MANAGED,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL
    });

    const idempotency = new dynamodb.Table(this, "IdempotencyTable", {
      partitionKey: { name: "idempotency_key", type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      timeToLiveAttribute: "ttl_epoch"
    });

    const dlq = new sqs.Queue(this, "DLQ", {
      retentionPeriod: cdk.Duration.days(14)
    });

    const queue = new sqs.Queue(this, "Queue", {
      visibilityTimeout: cdk.Duration.seconds(180),
      receiveMessageWaitTime: cdk.Duration.seconds(20),
      deadLetterQueue: { queue: dlq, maxReceiveCount: 5 }
    });

    const worker = new lambda.Function(this, "Worker", {
      runtime: lambda.Runtime.NODEJS_20_X,
      handler: "handler.handler",
      code: lambda.Code.fromAsset("../packages/lambda-worker"), // adjust path in real repo
      timeout: cdk.Duration.seconds(30),
      environment: {
        QUARANTINE_BUCKET: quarantine.bucketName,
        IDEMPOTENCY_TABLE: idempotency.tableName
      }
    });

    queue.grantConsumeMessages(worker);
    quarantine.grantReadWrite(worker);
    idempotency.grantReadWriteData(worker);

    worker.addEventSource(new sources.SqsEventSource(queue, {
      batchSize: 10,
      reportBatchItemFailures: true
    }));

    new cw.Alarm(this, "DLQDepthAlarm", {
      metric: dlq.metricApproximateNumberOfMessagesVisible({ period: cdk.Duration.minutes(1) }),
      threshold: 0,
      evaluationPeriods: 1,
      comparisonOperator: cw.ComparisonOperator.GREATER_THAN_THRESHOLD,
      alarmDescription: "DLQ has messages; investigate quarantine/replay."
    });

    new cdk.CfnOutput(this, "QueueUrl", { value: queue.queueUrl });
    new cdk.CfnOutput(this, "DLQUrl", { value: dlq.queueUrl });
    new cdk.CfnOutput(this, "QuarantineBucket", { value: quarantine.bucketName });
    new cdk.CfnOutput(this, "IdempotencyTable", { value: idempotency.tableName });
  }
}
