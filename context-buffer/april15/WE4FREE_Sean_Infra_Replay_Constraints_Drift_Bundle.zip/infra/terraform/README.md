# Terraform infra module (WE4FREE / Sean resilience baseline)

Creates:
- SQS queue + DLQ (with redrive policy)
- Lambda worker + event source mapping (ReportBatchItemFailures)
- S3 quarantine bucket
- DynamoDB idempotency table (TTL)
- CloudWatch alarm on DLQ depth

## Usage
```bash
terraform init
terraform apply   -var="lambda_zip_path=./lambda.zip"   -var="quarantine_bucket_name=<globally-unique-bucket>"
```
