variable "aws_region" { type = string, default = "us-east-1" }
variable "name_prefix" { type = string, default = "we4free-sean" }
variable "tags" { type = map(string), default = {} }

variable "lambda_zip_path" {
  type = string
  description = "Path to zipped Lambda artifact (built separately)."
}

variable "lambda_handler" {
  type = string
  default = "handler.handler"
}

variable "lambda_timeout_seconds" { type = number, default = 30 }
variable "visibility_timeout_seconds" { type = number, default = 180 }
variable "max_receive_count" { type = number, default = 5 }
variable "sqs_batch_size" { type = number, default = 10 }

variable "quarantine_bucket_name" {
  type = string
  default = "we4free-sean-quarantine-example"
}

variable "resilience_policy_s3_uri" {
  type = string
  description = "Optional: S3 URI to a policy JSON used by the runtime."
  default = ""
}

variable "dlq_depth_alarm_threshold" { type = number, default = 0 }
